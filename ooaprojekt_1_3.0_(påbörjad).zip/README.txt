Grupp 1 - DAT055 2014

Det h�r �r en fungerande server samt testklient som skulle implementeras i v�rt spel f�r milstolpe 3, men det hann vi inte. Den �r testad skarpt �ver internet och det fungerar bra. Testa klienten, servern �r antagligen ig�ng.